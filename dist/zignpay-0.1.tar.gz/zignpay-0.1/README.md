# ZIGNPAY

A package to manage mobile payments using the MTN MoMo and Orange Money APIs

## Installation

```bash
  pip install zignpay
```
